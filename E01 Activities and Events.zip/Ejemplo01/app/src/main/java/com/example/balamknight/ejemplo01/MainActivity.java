package com.example.balamknight.ejemplo01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button botonAceptar;
    Button botonForm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botonAceptar = (Button) findViewById(R.id.btnAceptar);
        botonForm = (Button) findViewById(R.id.btnForm);
        botonForm.setOnClickListener(this);


        //a)
        botonAceptar.setOnClickListener( new View.OnClickListener() {

            public void onClick( View v)
            {
                EditText inputField1;
                inputField1 = (EditText) findViewById(R.id.editText);

                inputField1.setText("Hola Mundo");
            }
        }




        );

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnForm:
            {
                EditText inputField1;
                inputField1 = (EditText) findViewById(R.id.editText);

                Intent int1 = new Intent(this,SecondActivity.class);
                int1.putExtra("param1","Texto Ingresado: " + inputField1.getText());
                startActivity(int1);
                break;
            }
        }
    }
}
