package com.example.balamknight.ejemplo01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent paramInt = getIntent();

        String msg = paramInt.getStringExtra("param1");

        TextView label1 = (TextView) findViewById (R.id.textView2);
        label1.setText(msg);

    }
}
